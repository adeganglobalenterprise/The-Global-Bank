package com.globalbank.api

import com.globalbank.GlobalBankApplication
import com.globalbank.models.*
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.*

interface GlobalBankApiService {
    
    @POST(&quot;auth/login&quot;)
    suspend fun login(@Body request: LoginRequest): LoginResponse
    
    @POST(&quot;auth/register&quot;)
    suspend fun register(@Body request: RegisterRequest): RegisterResponse
    
    @GET(&quot;user/profile&quot;)
    suspend fun getUserProfile(@Header(&quot;Authorization&quot;) token: String): User
    
    @GET(&quot;user/balance&quot;)
    suspend fun getBalance(@Header(&quot;Authorization&quot;) token: String): BalanceResponse
    
    @POST(&quot;transaction/credit&quot;)
    suspend fun creditAccount(
        @Header(&quot;Authorization&quot;) token: String,
        @Body request: CreditRequest
    ): TransactionResponse
    
    @POST(&quot;transaction/debit&quot;)
    suspend fun debitAccount(
        @Header(&quot;Authorization&quot;) token: String,
        @Body request: DebitRequest
    ): TransactionResponse
    
    @POST(&quot;transaction/transfer&quot;)
    suspend fun transferFunds(
        @Header(&quot;Authorization&quot;) token: String,
        @Body request: TransferRequest
    ): TransactionResponse
    
    @GET(&quot;transaction/history&quot;)
    suspend fun getTransactionHistory(
        @Header(&quot;Authorization&quot;) token: String,
        @Query(&quot;page&quot;) page: Int = 1,
        @Query(&quot;limit&quot;) limit: Int = 20
    ): List&lt;Transaction&gt;
    
    @POST(&quot;wallet/generate-address&quot;)
    suspend fun generateCryptoAddress(
        @Header(&quot;Authorization&quot;) token: String,
        @Body request: GenerateAddressRequest
    ): CryptoAddressResponse
    
    @GET(&quot;admin/customers&quot;)
    suspend fun getAllCustomers(@Header(&quot;Authorization&quot;) token: String): List&lt;User&gt;
    
    @GET(&quot;admin/transactions&quot;)
    suspend fun getAllTransactions(@Header(&quot;Authorization&quot;) token: String): List&lt;Transaction&gt;
    
    @POST(&quot;admin/settings/mining&quot;)
    suspend fun toggleMining(
        @Header(&quot;Authorization&quot;) token: String,
        @Body request: MiningToggleRequest
    ): SettingsResponse
    
    companion object {
        private const val BASE_URL = GlobalBankApplication.API_BASE_URL
        
        fun create(): GlobalBankApiService {
            return Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build()
                .create(GlobalBankApiService::class.java)
        }
    }
}

// Request/Response Models
data class LoginRequest(
    val email: String,
    val password: String
)

data class LoginResponse(
    val success: Boolean,
    val token: String,
    val user: User
)

data class RegisterRequest(
    val firstName: String,
    val lastName: String,
    val email: String,
    val phone: String,
    val password: String
)

data class RegisterResponse(
    val success: Boolean,
    val message: String,
    val user: User
)

data class BalanceResponse(
    val balance: Double,
    val cryptoBalance: Double,
    val minedCoins: Double,
    val currency: String
)

data class CreditRequest(
    val userEmail: String,
    val amount: Double,
    val currency: String,
    val method: String,
    val description: String
)

data class DebitRequest(
    val userEmail: String,
    val amount: Double,
    val currency: String,
    val reason: String
)

data class TransferRequest(
    val toEmail: String,
    val amount: Double,
    val currency: String,
    val method: String,
    val network: String?
)

data class TransactionResponse(
    val success: Boolean,
    val transaction: Transaction,
    val message: String
)

data class GenerateAddressRequest(
    val currency: String
)

data class CryptoAddressResponse(
    val success: Boolean,
    val address: String,
    val currency: String
)

data class MiningToggleRequest(
    val enabled: Boolean
)

data class SettingsResponse(
    val success: Boolean,
    val miningEnabled: Boolean,
    val message: String
)

object ApiClient {
    private lateinit var apiService: GlobalBankApiService
    
    fun initialize() {
        apiService = GlobalBankApiService.create()
    }
    
    fun getApiService(): GlobalBankApiService {
        return apiService
    }
}